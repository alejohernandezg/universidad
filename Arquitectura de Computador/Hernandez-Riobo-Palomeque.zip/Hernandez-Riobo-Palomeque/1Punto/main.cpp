/*
	Alejandro Hernandez - Rooselvelt Riobo - Carlos Palomeque
	02/03/17
	Problema 1
*/


#include "Problema1.h"

int main()
{
	int valor;
	string color;

	CajaGrande objCajaGrande;
	CajitaMisterio miCajaMisterio;
	cout << "Digite un entero:";
	cin >> valor;
	cout << endl;
	cout << "Digite un color:";
	cin >> color;

	objCajaGrande.cambiarColorObjCajitaMisterio(color);
	objCajaGrande.verColor();
	miCajaMisterio.actualizarEntero(valor);
	cout << miCajaMisterio.consultarEntero() << endl;

	CajaGrandePtr objCajaGrandePtr(miCajaMisterio);
	cout <<objCajaGrandePtr.getEntero()<< endl; 

}