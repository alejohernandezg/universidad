#include "3Punto.h"/*Roosevelt Andres Riobo- Alejandro Hernandez - Carlos Palomeque */



int main(){
	vector<libros> crearLibro;
	int cuantosLibros;
	int nuevaEdicion;
	string autor;
	cout<<"Cuantos libros quieres : "<<endl;
	cin>>cuantosLibros;
	cout<<"Digite la edicion y el autor : "<<cuantosLibros<<" veces "<<endl;
	crearLibro.resize(cuantosLibros);
	for (int i = 0; i < cuantosLibros; i++){
		cin>>nuevaEdicion;
		cout<<endl;
		getline(cin,autor);	
		crearLibro[i].edicion=nuevaEdicion;
		crearLibro[i].autor=autor;
	}

	for (int i = 0; i < cuantosLibros; i++){
		cout<<endl;
		cout<<crearLibro[i].edicion;
		cout<<crearLibro[i].autor;
		cout<<endl;
	}

	
}