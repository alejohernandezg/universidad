class instruccion:
    opcode= "" #El tamaño del opcode sera de 7 bits
    primerRegistro = ""
    segundoRegistro = ""
    constante = "" #El valor maximo que puede tomar la constante sera de 5 bits

    
    def __init__(self, nOpcode,nPrimerR,nSegundoR,nConstante):
        self.opcode = nOpcode
        self.primerRegistro = nPrimerR
        self.segundoRegistro = nSegundoR
        self.constante = nConstante

    def imprimir(self):
        print("OPCODE:", self.opcode , "PRIMER REGISTRO:", self.primerRegistro, "SEGUNDO REGISTRO:", self.segundoRegistro,
              "CONSTANTE:", self.constante)