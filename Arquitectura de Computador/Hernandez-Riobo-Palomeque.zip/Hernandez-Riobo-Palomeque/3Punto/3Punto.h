#include <iostream>
#include <stdlib.h>
#include <stdio.h>  
#include <algorithm>
#include <string>
#include <iterator>
#include <vector>
/*Roosevelt Andres Riobo- Alejandro Hernandez - Carlos Palomeque */

using namespace std;

class obras{
protected:
	string nombre;
	string identificacion;
public:
	obras(){};
	~obras(){};
};


class libros:public obras{
public:
int edicion;
string autor;
	libros(){};
	~libros(){};

};


class CD:public obras{
public:
string tema;
string autor;
	CD(){};
	~CD(){};


};


class revista:public obras{
public:
int tiraje;
int pericidad;
	revista(){};
	~revista(){};

};