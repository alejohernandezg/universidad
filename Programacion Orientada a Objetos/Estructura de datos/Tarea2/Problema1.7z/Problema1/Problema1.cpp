#include "Problema1.h"


Cajita::Cajita(int valor)
{
	entero=valor;
};


void CajitaMisterio::setColor(int nuevoColor){
	color = nuevoColor;
};
int CajitaMisterio::consultarEntero(){return entero;};

void CajitaMisterio::actualizarEntero(int valor){
	entero = valor;
};

void CajitaMisterio::getColor(){
	cout << color << endl;
}


void CajaGrande::cambiarColorObjCajitaMisterio(int nuevoColor){
	objCajitaMisterio.setColor(nuevoColor);
};

void CajaGrande::verColor(){
	objCajitaMisterio.getColor();
}

int CajaGrandePtr::getEntero(){
	ptrObjCajitaMisterio->consultarEntero();
};

void CajaGrandePtr::setEntero(int valor){
	ptrObjCajitaMisterio->actualizarEntero(valor);
};