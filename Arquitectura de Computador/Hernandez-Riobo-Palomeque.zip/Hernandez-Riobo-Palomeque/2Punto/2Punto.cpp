#include "2Punto.h"

/*Roosevelt Andres Riobo- Alejandro Hernandez - Carlos Palomeque */



bool generador::generarBitAleatorio(){
	int bitAleatorio;
	bool bandera;
	std::srand(std::time(0));
	bitAleatorio=rand()%2;
	cout<<"El bit aleatorio es : "<<endl;
	cout<<bitAleatorio;
	if(bitAleatorio==1){
		return true;
	}
	return false;
}

int generador::generarValorAleatorio(int umbral){
	int maximo=umbral;
	int numero;
	std::srand(std::time(0));
	numero=rand()%maximo;
	cout<<"El valor aleatorio es : "<<endl;
	cout<<numero;
	return numero;
}

void generador::generarValorAleatorio(int inferior,int superior){
	int maximo=superior;
	int minimor=inferior;
	int numero;
	std::srand(std::time(0));
	superior+=1;    //para que vaya hasta el superior exactamente. 
	numero=inferior+rand()%(superior-inferior);
	cout<<"El valor aleatorio entre minimo y maximo : "<<endl;
	cout<<numero;
}