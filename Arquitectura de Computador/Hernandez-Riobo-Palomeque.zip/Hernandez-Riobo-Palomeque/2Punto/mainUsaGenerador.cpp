#include "2Punto.h"

/*Roosevelt Andres Riobo- Alejandro Hernandez - Carlos Palomeque */



int main(){
	int inferior;
	int superior;
	usaGenerador *ptrObjGenerador;
	cout<<"Digite el limite inferior : "<<endl;
	cin>>inferior;
	cout<<"Digite el limite superior : "<<endl;
	cin>>superior;
	ptrObjGenerador->generarValorAleatorio(inferior,superior);
	return 0;
}




