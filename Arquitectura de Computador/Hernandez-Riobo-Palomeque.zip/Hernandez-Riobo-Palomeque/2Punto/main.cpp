#include "2Punto.h"

/*Roosevelt Andres Riobo- Alejandro Hernandez - Carlos Palomeque */



int main(){
	generador miGenerador;
	int inferior;
	int superior;
	int _maximo;
	miGenerador.generarBitAleatorio();
	cout<<endl;
	cout<<"Ingrese el maximo del numero aleatorio : "<<endl;
	cin>>_maximo;
	miGenerador.generarValorAleatorio(_maximo);
	cout<<endl;
	cout<<"Digite el limite inferior : "<<endl;
	cin>>inferior;
	cout<<"Digite el limite superior : "<<endl;
	cin>>superior;
	miGenerador.generarValorAleatorio(inferior,superior); 	
	return 0;
}