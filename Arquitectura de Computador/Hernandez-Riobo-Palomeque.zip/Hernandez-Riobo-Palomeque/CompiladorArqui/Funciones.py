import re
from claseInstruccion import instruccion

listaOpCode0al48 = {'ADD': 0,'SUB': 7,'AND': 14,'OR': 21,'MUL': 28,'DIV': 35,'MOV': 42}

listaOpCode56al83 = {'ADD': 56,'SUB': 60,'AND': 64,'OR': 68,'MUL': 72,'DIV': 76,'MOV': 80}
listaOpCode84al90 ={'ADD': 85,'SUB': 86,'AND': 89,'OR': 90,'MUL': 87,'DIV': 88,'MOV': 84}
listaBranch= {'BRM': 49,'BRI': 50,'SHL': 52,'SHR': 53,'BRME': 51}
listaRegistros = {'1': "0001", '2': "0010", '3': "0011", '4': "0100", '5': "0101", '6': "0110", '7': "0111",
                 '8': "1000", '9': "1001", }
mapaEtiquetas ={}

#Crea un mapa con las etiquetas que hayan en el programa con su respectivo numero de fila
def buscar_Etiquetas(programa):
    contadorLinea = 0
    for linea in programa:
        if re.match("^[a-zA-Z0-9]*$",linea) and linea != "\n":
            mapaEtiquetas[linea] =  contadorLinea
        contadorLinea +=1
    return  mapaEtiquetas


def convertir(nombreArchivo):
    programa = open(nombreArchivo)
    mapaEtiquetas = buscar_Etiquetas(programa)
    programa = open(nombreArchivo)
    listaInstrucciones = []
    pcActual = 0
    for linea in programa:

        if re.match("^[A-Z]{,3}\s[R][0-9]\,[R][0-9]$",linea):  #Para las tipo R1,R2
            miOpCode = obtener_OpCode(linea,0)
            misRegistros = obtener_registros(linea)
            registro1 = misRegistros[2]
            registro2 = misRegistros[5]
            constante = ""
            miInstruccion = instruccion(miOpCode,registro1,registro2,constante)
            listaInstrucciones.append(miInstruccion)
            pcActual += 1
            continue
        elif re.match("^[A-Z]{,3}\s[R][0-9]\,[0-9]{,3}$",linea): #Para las tipo R1,const
            miOpCode = obtener_OpCode(linea,0) + 1
            misRegistros = obtener_registros(linea)
            registro1 = misRegistros[2]
            registro2 = ""
            constante = misRegistros[4:]
            miInstruccion = instruccion(miOpCode, registro1, registro2, constante)
            listaInstrucciones.append(miInstruccion)
            pcActual += 1
            continue
        elif re.match("^[A-Z]{,3}\s\[[R][0-9]\]\,[R][0-9]$",linea): #Para las tipo [R1],R2
            miOpCode = obtener_OpCode(linea,0) + 2
            misRegistros = obtener_registros(linea)
            registro1 = misRegistros[3]
            registro2 = misRegistros[7]
            constante = "0"
            miInstruccion = instruccion(miOpCode,registro1,registro2,constante)
            listaInstrucciones.append(miInstruccion)
            pcActual += 1
            continue
        elif re.match("^[A-Z]{,3}\s\[[R][0-9]\+[0-9]{1,3}\]\,[R][0-9]$", linea): #Para las tipo [R1+const],R2
            miOpCode = obtener_OpCode(linea,0) + 3
            misRegistros = obtener_registros(linea)
            registro1 = misRegistros[3]
            registro2 = misRegistros[9]
            constante = obtener_constante(linea,0)
            miInstruccion = instruccion(miOpCode, registro1, registro2, constante)
            listaInstrucciones.append(miInstruccion)
            pcActual += 1
            continue
        elif re.match("^[A-Z]{,3}\s[R][0-9]\,\[[R][0-9]\]$",linea): #Para las tipo R1,[R2]
            miOpCode = obtener_OpCode(linea,0) + 4
            misRegistros = obtener_registros(linea)
            registro1 = misRegistros[2]
            registro2 = misRegistros[6]
            constante = "0"
            miInstruccion = instruccion(miOpCode, registro1, registro2, constante)
            listaInstrucciones.append(miInstruccion)
            pcActual += 1
            continue
        elif re.match("^[A-Z]{,3}\s[R][0-9]\,\[[R][0-9]\+[0-9]{1,3}\]$", linea): #Para las tipo R1,[R2+const]
            miOpCode = obtener_OpCode(linea,0) + 5
            misRegistros = obtener_registros(linea)
            registro1 = misRegistros[2]
            registro2 = misRegistros[6]
            constante = obtener_constante(linea,0)
            miInstruccion = instruccion(miOpCode, registro1, registro2, constante)
            listaInstrucciones.append(miInstruccion)
            pcActual += 1
            continue
        elif re.match("^([A-Z]){,3}\s\[[R][0-9]\]\,\[[R][0-9]\]$",linea): #Para las tipo [R1],[R2]
            miOpCode = obtener_OpCode(linea,0) + 6
            misRegistros = obtener_registros(linea)
            registro1 = misRegistros[3]
            registro2 = misRegistros[8]
            constante = "0"
            miInstruccion = instruccion(miOpCode, registro1, registro2, constante)
            listaInstrucciones.append(miInstruccion)
            pcActual += 1
            continue
        elif re.match("^[A-Z]{,4}\s[R]\d+\,[R]\d+\,[a-zA-Z0-9]*$",linea): #Para los Branch
            miOpCode = obtener_OpCode(linea,2)
            misRegistros = obtener_registros(linea)
            registro1 = misRegistros[2]
            registro2 = misRegistros[5]
            #Agregado el dia 12/09/2017 para añadir los SHL y SHR
            if miOpCode == 52 or miOpCode == 53:
                constante = misRegistros[7:]
            else:
                constante = obtener_constanteBranch(misRegistros,pcActual,mapaEtiquetas,0)
            #---------------------------------------------------------
            miInstruccion = instruccion(miOpCode, registro1, registro2, constante)
            listaInstrucciones.append(miInstruccion)
            pcActual += 1
            continue
        elif re.match("^([A-Z]){,3}\s[R][0-9]\,\[[0-9]{,3}\]$",linea): #Para las tipo R1,[const]
            miOpCode = obtener_OpCode(linea,1)
            misRegistros = obtener_registros(linea)
            registro1 = misRegistros[2]
            registro2 = ""
            constante = obtener_constante(linea,1)
            miInstruccion = instruccion(miOpCode, registro1, registro2, constante)
            listaInstrucciones.append(miInstruccion)
            pcActual += 1
            continue
        elif re.match("^([A-Z]){,3}\s\[[R][0-9]\]\,\[[0-9]{1,2}\]$",linea): #Para las tipo [R1],[const]
            miOpCode = obtener_OpCode(linea,1) + 1
            misRegistros = obtener_registros(linea)
            registro1 = misRegistros[3]
            registro2 = ""
            constante = obtener_constante(linea, 1)
            miInstruccion = instruccion(miOpCode, registro1, registro2, constante)
            listaInstrucciones.append(miInstruccion)
            pcActual += 1
            continue
        elif re.match("^([A-Z]){,3}\s\[[0-9]{1,2}\]\,[R][0-9]$",linea): #Para las tipo [const],R1
            miOpCode = obtener_OpCode(linea,1) + 2
            misRegistros = obtener_registros(linea)
            registro1 = ""
            registro2 = linea[len(linea)-2]
            constante = obtener_constante(linea, 1)
            miInstruccion = instruccion(miOpCode, registro1, registro2, constante)
            listaInstrucciones.append(miInstruccion)
            pcActual += 1
            continue
        elif re.match("^([A-Z]){,3}\s\[[0-9]{1,2}\]\,\[[R][0-9]\]$",linea): #Para las tipo [const],[R1]
            miOpCode = obtener_OpCode(linea,1) + 3
            misRegistros = obtener_registros(linea)
            registro1 = ""
            registro2 = linea[len(linea)-3]
            constante = obtener_constante(linea, 1)
            miInstruccion = instruccion(miOpCode, registro1, registro2, constante)
            listaInstrucciones.append(miInstruccion)
            pcActual += 1
            continue
        elif re.match("^[A-Z]{,3}\s\[[R][0-9]\+[0-9]{1,2}\]\,\[[R][0-9]\]$",linea): #Para las tipo [R1+const], [R2]
            miOpCode = obtener_OpCode(linea, 3)
            misRegistros = obtener_registros(linea)
            registro1 = linea[len(linea)- 10]
            registro2 = linea[len(linea) - 3]
            constante = obtener_constante(linea, 3)
            miInstruccion = instruccion(miOpCode, registro1, registro2, constante)
            listaInstrucciones.append(miInstruccion)
            pcActual += 1
        elif re.match("^[J][U][M][P]\s[a-zA-Z0-9]*$",linea):
            miOpCode = "55"
            direccion = obtener_registros(linea)
            registro1 = ""
            registro2 = ""
            constante = obtener_constanteBranch(direccion,pcActual,mapaEtiquetas,1)
            miInstruccion = instruccion(miOpCode, registro1, registro2, constante)
            listaInstrucciones.append(miInstruccion)
            pcActual += 1
            continue
        elif re.match("^[N][O][P]*$",linea):
            miOpCode = "54"
            registro1 = ""
            registro2 = ""
            constante = ""
            miInstruccion = instruccion(miOpCode, registro1, registro2, constante)
            listaInstrucciones.append(miInstruccion)
            pcActual += 1
            continue
    return listaInstrucciones


#Retorna una cadena con los registros que hay despues del espacio.
def obtener_registros(linea):
    agregar = False
    misRegistros = ""
    for letra in linea:
        if letra == " ":
            agregar = True
        if agregar:
            misRegistros += letra
    return misRegistros

#Obtiene las constantes dependiendo del tipo y como esta compuesta la instruccion
def obtener_constante(linea,tipoRegistro):
    agregar = False
    constante = ""
    if tipoRegistro == 0 or tipoRegistro == 3:
        for letra in linea:
            if agregar and letra != "]":
                constante += letra
            if letra == "]":
                agregar = False
            if letra == "+":
                agregar = True
        return constante
    if tipoRegistro == 1:
        for letra in linea:
            if letra == "R":
                agregar = False
            if agregar and letra != "]" and letra != "R":
                constante += letra
            if letra == "]":
                agregar = False
            if letra == "[":
                agregar = True
        return constante

#Obtiene la constante del branch con respecto a un diccionario que contiene la posicion de cada etiqueta
def obtener_constanteBranch(misRegistros,pcActual,mapaEtiquetas,tipoEtiqueta):
    etiqueta = ""
    pcActual +=2
    misRegistros2 = misRegistros[1:]
    misRegistros2 += "\n"
    for etiquetaGuardada in mapaEtiquetas:
        if misRegistros2 == etiquetaGuardada and tipoEtiqueta == 1:
            pcEtiqueta = str(mapaEtiquetas[etiquetaGuardada])
            return pcEtiqueta
        if etiquetaGuardada == misRegistros[7:] and tipoEtiqueta == 0:
            pcEtiqueta = str(mapaEtiquetas[etiquetaGuardada] - pcActual)
            return pcEtiqueta


#Busca el opcode en un diccionario unas instrucciones establecidas
def obtener_OpCode(linea,tipoRegistro):
    opcode=""
    opCodeNum = 0
    for letra in linea:
        if letra == " ":
            break
        else:
            opcode += letra
    if tipoRegistro == 0:
        for opCodeDiccionario in listaOpCode0al48:
            if opCodeDiccionario == opcode:
                opCodeNum = listaOpCode0al48[opCodeDiccionario]
        return opCodeNum
    if tipoRegistro == 1:
        for opCodeDiccionario in listaOpCode56al83:
            if opCodeDiccionario == opcode:
                opCodeNum = listaOpCode56al83[opCodeDiccionario]
        return opCodeNum
    if tipoRegistro == 3:
        for opCodeDiccionario in listaOpCode84al90:
            if opCodeDiccionario == opcode:
                opCodeNum = listaOpCode84al90[opCodeDiccionario]
        return opCodeNum
    if tipoRegistro == 2:
        for opCodeDiccionario in listaBranch:
            if opCodeDiccionario == opcode:
                opCodeNum = listaBranch[opCodeDiccionario]
        return opCodeNum


#CREA EL ARCHIVO Y AÑADE LOS STRINGS EN BINARIO DE LAS INSTRUCCIONES
def compilar(misInstrucciones):
    archivoCompilado = open("programaVonCompilado.txt","w")
    numeroLinea = 0
    for instruccion in misInstrucciones:
        miOpCode = convertirOpCode(instruccion)
        miPrimerRegistro = convertirRegistro(instruccion)
        miSegundoRegistro = convertirRegistro2(instruccion)
        miconstante = convertirConstante(instruccion)
        #Para poder ver bien el codigo en binario, quite el comentario de la fila de abajo------------------------
        #print("LINEA:",numeroLinea,"OP:",miOpCode,"PRIMER REGISTRO:",miPrimerRegistro,"SEGUNDO REGISTRO:", miSegundoRegistro,"CONSTANTE:", miconstante)
        #----------------------------------------------------------------------------------------------------------
        lineaArchivo = miOpCode + miPrimerRegistro + miSegundoRegistro + miconstante
        numeroLinea +=1
        archivoCompilado.write(lineaArchivo)
        archivoCompilado.write("\n")


#OPERACIONES PARA CONVERSIONES DE STRING A BINARIO
def convertirConstante(instruccion):
    for x in instruccion.constante:
        if x == "-":
            constante = x[1:]
            constante = int(instruccion.constante)
            constanteBin = bin(constante)
            constanteBin = constanteBin[3:]
            while len(constanteBin) != 5:
                constanteBin = "0"+constanteBin
            return "1"+constanteBin
    if instruccion.constante == "":
        return "000000"
    else:
        constante = int(instruccion.constante)
        constanteBin = bin(constante)
        constanteBin = constanteBin[2:]

        while len(constanteBin) !=5:
            constanteBin = "0" + constanteBin
        return "0" + constanteBin

def convertirRegistro(instruccion):
    if instruccion.primerRegistro == "":
        return "0000"
    for registro in listaRegistros:
        if registro == instruccion.primerRegistro:
            return listaRegistros[registro]

def convertirRegistro2(instruccion):
    if instruccion.segundoRegistro == "":
        return "0000"
    for registro in listaRegistros:
        if registro == instruccion.segundoRegistro:
            return listaRegistros[registro]

def convertirOpCode(instruccion):
    op = int(instruccion.opcode)
    opBin = bin(op)
    opBin = opBin[2:]

    while len(opBin) != 7:
        opBin = "0" + opBin
    return opBin
#----------------------------------------------------------------------------------