/*
	Alejandro Hernandez - Rooselvelt Riobo - Carlos Palomeque
	02/03/17
	Problema 1
*/

#include <iostream>
#include <cstring>

using namespace std;


// PUNTO A (Se genera la clase Cajita y se realiza su implementacion)---------
class Cajita
{
protected:
	int entero;
public:
	Cajita( ){};
	Cajita(int valor);
	virtual ~Cajita( ){};
	virtual int consultarEntero( );
	virtual void actualizarEntero(int valor);
};



// PUNTO B (Implementa la clase CajitaMisterio que es subclase de Cajita)------
class CajitaMisterio:public Cajita
{
private:
	int color;
public:
	CajitaMisterio(){};
	~CajitaMisterio(){};
	void setColor(int nuevoColor);
	void getColor();
	int consultarEntero();
	void actualizarEntero(int valor);

};



//PUNTO C -----------------------------------------------------------------------------

class CajaGrande
{
private:
	CajitaMisterio objCajitaMisterio;
public:
	CajaGrande(){};
	~CajaGrande(){};
	void cambiarColorObjCajitaMisterio(int nuevoColor);
	void verColor();
};



//PUNTO D-----------------------------------------------------------------------------


class CajaGrandePtr
{
private:
	CajitaMisterio * ptrObjCajitaMisterio;
public:
	CajaGrandePtr(){};
	~CajaGrandePtr(){};
	int getEntero();
	void setEntero(int valor);
};

