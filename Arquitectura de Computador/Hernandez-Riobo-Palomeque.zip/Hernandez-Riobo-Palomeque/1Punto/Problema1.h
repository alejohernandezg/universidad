/*
	Alejandro Hernandez - Rooselvelt Riobo - Carlos Palomeque
	02/03/17
	Problema 1
*/

#include <iostream>
#include <cstring>

using namespace std;


// PUNTO A (Se genera la clase Cajita y se realiza su implementacion)---------
class Cajita
{
protected:
	int entero;
public:
	Cajita( ){};
	Cajita(int valor);
	~Cajita( ){};
	int consultarEntero( );
	void actualizarEntero(int valor);
};

Cajita::Cajita(int valor)
{
	entero=valor;
};


// PUNTO B (Implementa la clase CajitaMisterio que es subclase de Cajita)------
class CajitaMisterio:public Cajita
{
private:
	string color;
public:
	CajitaMisterio() {};
	~CajitaMisterio(){};
	void setColor(string);
	void getColor();
	int consultarEntero();
	void actualizarEntero(int valor);

};

void CajitaMisterio::setColor(string nuevoColor){
	color = nuevoColor;
};

void CajitaMisterio::getColor(){
	cout << color << endl;
};

int CajitaMisterio::consultarEntero(){return entero;};

void CajitaMisterio::actualizarEntero(int valor){
	entero = valor;
};



//PUNTO C -----------------------------------------------------------------------------

class CajaGrande
{
private:
	CajitaMisterio objCajitaMisterio;
public:
	CajaGrande(){};
	~CajaGrande(){};
	void cambiarColorObjCajitaMisterio(string nuevoColor);
	void verColor();
};

void CajaGrande::cambiarColorObjCajitaMisterio(string nuevoColor){
	objCajitaMisterio.setColor(nuevoColor);
};

void CajaGrande::verColor(){
	objCajitaMisterio.getColor();
}


//PUNTO D-----------------------------------------------------------------------------


class CajaGrandePtr
{
private:
	CajitaMisterio * ptrObjCajitaMisterio;
public:
	CajaGrandePtr(){};
	CajaGrandePtr(CajitaMisterio);
	~CajaGrandePtr(){};
	int getEntero();
	void setEntero(int valor);
};

CajaGrandePtr::CajaGrandePtr(CajitaMisterio miNuevaCajita){
	ptrObjCajitaMisterio = &miNuevaCajita;
}
int CajaGrandePtr::getEntero(){
	ptrObjCajitaMisterio->consultarEntero();
};

void CajaGrandePtr::setEntero(int valor){
	ptrObjCajitaMisterio->actualizarEntero(valor);
};



/*Profe la solucion del problema era meter
  todas las funciones del cpp al .h eso soluciono los problemas*/