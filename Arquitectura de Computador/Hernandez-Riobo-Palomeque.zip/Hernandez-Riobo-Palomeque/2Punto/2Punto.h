/*Roosevelt Andres Riobo- Alejandro Hernandez - Carlos Palomeque */


#include <iostream>
#include <stdlib.h>
#include <time.h>
#include <ctime>
#include <stdio.h>  
#include <algorithm>

using namespace std;


class generador{
private:
	int umbral;
	int inferior;
	int superior;
public:
	generador(){};
	~generador(){};
 	bool generarBitAleatorio();
	int generarValorAleatorio(int umbral);
	//Se genera sobrecarga el siguiente metodo tiene otro tipo de dato y 2 parametros:
	void generarValorAleatorio(int inferior,int superior);
	
};



class usaGenerador:public generador{
private:
	generador *ptrObjGenerador;
public:
	usaGenerador(){};
	~usaGenerador(){};
	//virtual bool generarBitAleatorio();
	//virtual int generarValorAleatorio(int umbral);
	//virtual void generarValorAleatorio(int inferior,int superior);
	
};