#include "Problema1.h"

int main()
{
	int hola= 123;
	CajaGrande cajaPalo;
	cajaPalo.cambiarColorObjCajitaMisterio(hola);
	cajaPalo.verColor();
};