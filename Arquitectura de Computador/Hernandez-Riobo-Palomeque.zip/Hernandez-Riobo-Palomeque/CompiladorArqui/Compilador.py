import os.path
import Funciones


def main():
    loop = True
    while(loop):
        nombreArchivo = ""
        print("Ingrese el nombre del archivo en el que esta el programa:")
        nombreArchivo = input()
        nombreArchivo = nombreArchivo + ".txt"

        if os.path.exists(nombreArchivo):
            misInstrucciones = Funciones.convertir(nombreArchivo)
            Funciones.compilar(misInstrucciones)
            break
        else:
            print("Archivo no encontrado")

main()